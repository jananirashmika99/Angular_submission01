import { componentFactoryName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.scss']
})
export class AboutusComponent implements OnInit {

  constructor() { }



  ngOnInit(): void {
  }
   show()
   {
     alert('Hello Jannai Rashmika');

   }
   shows()
   {
     
     alert('Hello,do you want to exit');
   }
}
