import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  users:any[]=[];

  constructor(private userService:UserService) { }

  ngOnInit(): void {
 this.userService.getUsers().subscribe(res =>
  
  {
    this.users=res as any[];
    console.log(res);
  }
  );
    
  }

}
